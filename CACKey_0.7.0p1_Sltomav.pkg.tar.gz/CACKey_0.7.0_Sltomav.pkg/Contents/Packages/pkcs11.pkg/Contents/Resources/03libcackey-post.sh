#!/bin/bash
chmod 755 /usr/lib/pkcs11
chown root:wheel /usr/lib/pkcs11
