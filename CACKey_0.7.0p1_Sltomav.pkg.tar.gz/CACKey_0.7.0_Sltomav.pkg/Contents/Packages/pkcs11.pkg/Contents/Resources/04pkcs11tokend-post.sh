#!/bin/bash
chmod -R go+rX /System/Library/Security/tokend/PKCS11.tokend
chown -R root:wheel /System/Library/Security/tokend/PKCS11.tokend
