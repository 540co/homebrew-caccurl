#!/bin/bash
chmod 755 /Library/CACKey
chown root:admin /Library/CACKey
